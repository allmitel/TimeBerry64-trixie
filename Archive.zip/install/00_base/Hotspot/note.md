## internet is "wificard_stub"
## hotspot is "hotspotcard_stub"
## I
## I    H
## H    I

## soit

## "wificard_stub"
## "wificard_stub" - "hotspotcard_stub"
## "hotspotcard_stub" - "wificard_stub"